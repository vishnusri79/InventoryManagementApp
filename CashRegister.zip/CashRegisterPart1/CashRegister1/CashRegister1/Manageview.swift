//  Manageview.swift
//  CashRegister1
//
//  Created by user238136 on 3/3/24.
//

import SwiftUI

struct HistoryItem: Identifiable {
    var id: UUID = UUID()
    var itemName: String
    var quantityLeft: Int
    var purchaseDate: Date
}

struct HistoryView: View {
    @Binding var itemQuantity: [String: Int]
    @State private var selectedProduct: String = ""
    @State private var showDetails: Bool = false
    @State private var selectedHistoryItem: HistoryItem?
    
    var body: some View {
        VStack {
            Text("History Page")
                .font(.largeTitle)
                .padding()
            
            // Display the list of purchased items and quantities left
            List(itemQuantity.sorted(by: <), id: \.key) { item in
                HStack {
                    Text(item.key)
                        .foregroundColor(.black)
                        .font(.headline)
                    Spacer()
                    Text("Quantity Left: \(item.value)")
                        .foregroundColor(.black)
                        .font(.headline)
                }
                .onTapGesture {
                    let historyItem = HistoryItem(itemName: item.key, quantityLeft: item.value, purchaseDate: Date())
                    selectedHistoryItem = historyItem
                    showDetails = true
                }
            }
        }
        .sheet(isPresented: $showDetails) {
            if let selectedHistoryItem = selectedHistoryItem {
                HistoryDetailsView(historyItem: selectedHistoryItem)
            }
        }
    }
}

struct HistoryDetailsView: View {
    var historyItem: HistoryItem
    
    var body: some View {
        VStack {
            Text("History Details")
                .font(.title)
                .padding()
            
            Text("Item: \(historyItem.itemName)")
                .padding()
            Text("Quantity Left: \(historyItem.quantityLeft)")
                .padding()
            Text("Purchase Date: \(historyItem.purchaseDate)")
                .padding()
            
            Spacer()
        }
    }
}
struct RestockView: View {
    @Binding var itemQuantity: [String: Int]
    @State private var selectedProduct: String = ""
    
    var body: some View {
        VStack {
            Text("Restock Page")
                .font(.largeTitle)
                .padding()
            
            // Display the list of items to restock
            List(itemQuantity.sorted(by: <), id: \.key) { item in
                HStack {
                    Text(item.key)
                        .foregroundColor(.black)
                        .font(.headline)
                    Spacer()
                    Text("Quantity Left: \(item.value)")
                        .foregroundColor(.black)
                        .font(.headline)
                }
                .onTapGesture {
                    selectedProduct = item.key
                }
            }
            
            if !selectedProduct.isEmpty {
                Text("Selected Product: \(selectedProduct)")
                    .font(.headline)
                    .padding()
                
                HStack {
                    Button(action: {
                        // Increment stock quantity
                        itemQuantity[selectedProduct, default: 0] += 1
                    }) {
                        Image(systemName: "plus")
                            .font(.title)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    
                    Button(action: {
                        // Decrement stock quantity if greater than 0
                        if let currentQuantity = itemQuantity[selectedProduct], currentQuantity > 0 {
                            itemQuantity[selectedProduct] = currentQuantity - 1
                        }
                    }) {
                        Image(systemName: "minus")
                            .font(.title)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                .padding()
            }
        }
    }
}


struct ManageView: View {
    @State private var itemQuantity: [String: Int] = [
        "Pants": 40,
        "Tshirts": 50,
        "Shoes": 20,
        "Hats": 35,
        "Dresses": 24
    ]
    @State private var showRestockView: Bool = false
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Manage")
                    .font(.largeTitle)
                    .padding()
                
                NavigationLink(destination: HistoryView(itemQuantity: $itemQuantity)) {
                    Text("History")
                        .foregroundColor(.white)
                        .font(.title)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding()
                
                Button(action: {
                    showRestockView = true
                }) {
                    Text("Restock")
                        .foregroundColor(.white)
                        .font(.title)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .padding()
                .sheet(isPresented: $showRestockView) {
                    RestockView(itemQuantity: $itemQuantity)
                }
            }
        }
    }
}

struct ManageView_Previews: PreviewProvider {
    static var previews: some View {
        ManageView()
    }
}
