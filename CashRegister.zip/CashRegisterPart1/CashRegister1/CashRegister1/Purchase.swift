//
//  Purchase.swift
//  CashRegister1
//
//  Created by user238136 on 3/4/24.
//

import Foundation
struct Purchase: Identifiable {
    let id = UUID() // Unique identifier for each purchase
    let name: String
    let quantity: Int
    let totalPrice: Double
    let purchaseDate: Date
}
