	//
//  CashRegister1App.swift
//  CashRegister1
//
//  Created by user238136 on 3/2/24.
//

import SwiftUI
@main
struct CashRegister1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

