//
//  CashRegister2.swift
//  CashRegister1
//
//  Created by user238136 on 3/3/24.
//

import SwiftUI

struct CashRegister2: View {
    @State private var itemQuantity: [String: Int] = [
        "Pants": 40,
        "Tshirts": 50,
        "Shoes": 20,
        "Hats": 35,
        "Dresses": 24
    ]
    
    @State private var selectedProduct: String = "Type"
    @State private var selectedQuantity: Int = 0
    @State private var totalPrice: Int = 0
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    
    let itemPrices: [String: Int] = [
        "Pants": 20,
        "Tshirts": 15,
        "Shoes": 50,
        "Hats": 10,
        "Dresses": 30
    ]
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Cash Register App")
                    .font(.largeTitle)
                    .foregroundColor(.black)
                    .padding(.top, 20)
                
                ZStack {
                    Rectangle()
                        .fill(Color.black)
                        .frame(height: 830)
                    
                    VStack(spacing: 80) {
                        Text(selectedProduct) // Dynamic label for selected product
                            .modifier(TitleStyle())
                            .id("productlabel")
                        Text("Total: $\(totalPrice)") // Dynamic label for total price
                            .modifier(TitleStyle())
                            .id("totalamountlabel")
                        
                        VStack(spacing: 10) {
                            ButtonRow(buttons: ["7", "8", "9"]) { button in
                                updateQuantity(button)
                            }
                            ButtonRow(buttons: ["4", "5", "6"]) { button in
                                updateQuantity(button)
                            }
                            ButtonRow(buttons: ["1", "2", "3"]) { button in
                                updateQuantity(button)
                            }
                            ButtonRow(buttons: ["0", "Buy"], isOrange: true) { button in
                                updateQuantity(button)
                            }
                            
                        }
                        .padding(.top, -250)
                        
                        Text("Quantity: \(selectedQuantity)") // Dynamic label for selected quantity
                            .modifier(QuantityTitleStyle())
                            .id("quantitylabel")
                           
                        NavigationLink(destination: ManageView()) {
                            Text("Manage")
                                .foregroundColor(.white)
                                .font(.title)
                                .frame(width: 100, height: 60)
                                .background(Color.blue)
                                .cornerRadius(15)
                                
                                
                        }
                        .padding(.top, -120)
                    }
                    
                    VStack {
                        ForEach(itemQuantity.sorted(by: <), id: \.key) { item in
                            HStack {
                                Button(action: {
                                    selectedProduct = item.key
                                    selectedQuantity = 0 // Reset selected quantity when a new item is selected
                                }) {
                                    Text(item.key)
                                        .foregroundColor(.white)
                                        .font(.headline)
                                    Text("(Price: $\(itemPrices[item.key] ?? 0))") // Display unit price
                                                       .foregroundColor(.white)
                                                       .font(.subheadline)
                                }
                                Spacer()
                                Text("\(item.value)")
                                    .foregroundColor(.white)
                                    .font(.headline)
                                
                                
                            }
                        }
                        .padding(5)
                    }
                    .padding(.top, 400)
                    .id("productsnamesandquantity")
                    
                    Spacer()
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
    
    func updateQuantity(_ button: String) {
        if let number = Int(button) {
            selectedQuantity = selectedQuantity * 10 + number
        } else if button == "Buy" {
            if selectedQuantity > 0 {
                if let price = itemPrices[selectedProduct], let availableQuantity = itemQuantity[selectedProduct] {
                    if selectedQuantity <= availableQuantity {
                        totalPrice = selectedQuantity * price
                        itemQuantity[selectedProduct] = availableQuantity - selectedQuantity
                        selectedQuantity = 0 // Reset selected quantity
                    } else {
                        showAlert = true
                        alertMessage = "Selected quantity exceeds available quantity."
                    }
                }
            } else {
                showAlert = true
                alertMessage = "Please select a quantity greater than zero."
            }
        }
    }
    
    struct CashRegister2_Previews: PreviewProvider {
        static var previews: some View {
            CashRegister2()
        }
    }
    
    struct TitleStyle: ViewModifier {
        func body(content: Content) -> some View {
            content
                .foregroundColor(.white)
                .font(.title)
                .fontWeight(.bold)
                .padding(.leading, -200)
                .padding(.top, -250)
        }
    }
    
    struct QuantityTitleStyle: ViewModifier {
        func body(content: Content) -> some View {
            content
                .foregroundColor(.white)
                .font(.title)
                .fontWeight(.bold)
                .padding(.leading, -200)
                .padding(.top, -70)
        }
    }
    
    struct ButtonRow: View {
        let buttons: [String]
        let isOrange: Bool
        let action: (String) -> Void
        
        init(buttons: [String], isOrange: Bool = false, action: @escaping (String) -> Void) {
            self.buttons = buttons
            self.isOrange = isOrange
            self.action = action
        }
        
        var body: some View {
            HStack(spacing: 10) {
                ForEach(buttons, id: \.self) { button in
                    Button(action: {
                        action(button)
                    }) {
                        Text(button)
                            .foregroundColor(.white)
                            .font(.title)
                    }
                    .frame(width: 100, height: 60)
                    .background(isOrange ? Color.orange : Color.blue)
                    .cornerRadius(15)
                }
            }
        }
    }
}
